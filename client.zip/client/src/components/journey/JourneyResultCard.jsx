import React, { useState, useEffect } from 'react';
import {
  Clock,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Eye,
  Bookmark,
  CheckCircle2,
  GitCompare,
  Ticket,
  AlertCircle,
  X,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import api from '../../services/api.js';
import {
  formatDuration,
  formatPrice,
  formatTime,
  formatDateDisplay,
  formatTransfers,
  getDayOffset,
  formatDayOffsetBadge,
  getPriceLabel,
  getRecommendationExplanation,
} from '../../utils/formatters.js';
import { JourneyLeg, getModeIcon } from './JourneyLeg.jsx';

/**
 * JourneyResultCard Component
 *
 * Implements Sections 8, 9, 10, 11, 12, 13, 14, 15, 18:
 * - Scannable 4-point hierarchy: Departure, Arrival, Duration, Cost
 * - Explicit arrival date and +1 day offset calculation
 * - Transparent "Why Yatrai recommends this" explanation for Best Overall
 * - Reduced badge density with semantic coloring
 * - Vertical multi-modal timeline without fabricating stops
 * - Clear distinction between "Total fare" vs "Estimated driving cost"
 * - Replaces "Legs" with "[ View itinerary ↓ ]" or "[ 2 segments · 1 transfer ↓ ]"
 * - Replaces "View Journey" with "View itinerary"
 * - Comparison selection support
 */
export function JourneyResultCard({
  journey,
  isTopPick = false,
  allJourneys = [],
  onViewJourney,
  onBookJourney,
  isSaved: initialSaved,
  onRemoveSaved,
  onToggleCompare,
  isCompared = false,
}) {
  const { isAuthenticated } = useAuth();
  const [isExpanded, setIsExpanded] = useState(false);
  const [saved, setSaved] = useState(initialSaved || false);
  const [saving, setSaving] = useState(false);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingError, setBookingError] = useState(null);

  const handleBookNow = async () => {
    setBookingLoading(true);
    setBookingError(null);
    try {
      const journeyId = journey.id || journey._id;
      // Preserve current booking context in sessionStorage
      sessionStorage.setItem(
        'yatrai_pending_booking',
        JSON.stringify({
          journeyId,
          journeySnapshot: journey,
          savedAt: Date.now(),
        })
      );

      setBookingModalOpen(false);

      if (!isAuthenticated) {
        // Case A: Redirect to login page
        if (onBookJourney) {
          onBookJourney(journey, false);
        } else {
          window.history.pushState(null, '', '/profile');
          window.dispatchEvent(new PopStateEvent('popstate'));
        }
      } else {
        // Case B: Logged in - proceed to booking page
        if (onBookJourney) {
          onBookJourney(journey, true);
        } else {
          window.history.pushState(null, '', `/booking?journeyId=${journeyId}`);
          window.dispatchEvent(new PopStateEvent('popstate'));
        }
      }
    } catch (err) {
      setBookingError(err.message || 'Unable to proceed to booking.');
    } finally {
      setBookingLoading(false);
    }
  };

  useEffect(() => {
    if (initialSaved !== undefined) {
      setSaved(initialSaved);
      return;
    }
    if (isAuthenticated && journey?.id) {
      api.savedJourneys
        .check(journey.id)
        .then((res) => {
          if (res?.data?.saved !== undefined) {
            setSaved(res.data.saved);
          }
        })
        .catch(() => {});
    }
  }, [isAuthenticated, journey?.id, initialSaved]);

  const handleToggleSave = async (e) => {
    e.stopPropagation();
    if (!isAuthenticated) return;
    if (!journey?.id || saving) return;

    setSaving(true);
    try {
      if (saved) {
        await api.savedJourneys.remove(journey.id);
        setSaved(false);
        if (onRemoveSaved) onRemoveSaved(journey.id);
      } else {
        await api.savedJourneys.save(journey.id);
        setSaved(true);
      }
    } catch {
      // Keep previous state
    } finally {
      setSaving(false);
    }
  };

  if (!journey) return null;

  const originName = journey.origin?.name || journey.origin?.city || 'Origin';
  const destinationName = journey.destination?.name || journey.destination?.city || 'Destination';
  const originCity = journey.origin?.city && journey.origin?.name !== journey.origin?.city ? journey.origin.city : null;
  const destinationCity = journey.destination?.city && journey.destination?.name !== journey.destination?.city ? journey.destination.city : null;

  const depTime = journey.departureTimeFormatted || formatTime(journey.departureTime);
  const arrTime = journey.arrivalTimeFormatted || formatTime(journey.arrivalTime);
  const depDate = journey.departureDateFormatted
    ? formatDateDisplay(journey.departureDateFormatted)
    : formatDateDisplay(journey.departureTime);
  const arrDate = journey.arrivalDateFormatted
    ? formatDateDisplay(journey.arrivalDateFormatted)
    : formatDateDisplay(journey.arrivalTime);

  // Mandatory Section 10: explicit arrival day offset
  const dayOffset =
    journey.dayOffset !== undefined
      ? journey.dayOffset
      : getDayOffset(journey.departureTime, journey.arrivalTime);
  const dayOffsetBadge = formatDayOffsetBadge(dayOffset);

  const durationText = formatDuration(journey.duration);
  const isEstimated = Boolean(journey.pricing?.isEstimated || journey.metadata?.isEstimatedPrice || journey.isEstimated);
  const fareSource = journey.pricing?.fareSource || journey.metadata?.fareSource || (isEstimated ? 'estimate' : null);
  const priceText = formatPrice(journey.totalPrice, journey.currency, { isEstimated, fareSource });
  const priceLabel = getPriceLabel(journey);

  const transfers = journey.numberOfTransfers ?? 0;
  const isDirect = transfers === 0;

  const transportModes = Array.isArray(journey.transportModes) && journey.transportModes.length > 0
    ? journey.transportModes
    : ['rail'];

  const legs = Array.isArray(journey.legs) ? journey.legs : [];
  const isMultiModal = transfers > 0 || legs.length > 1;

  // Primary mode icon
  const PrimaryModeIcon = getModeIcon(transportModes[0] || 'rail');

  // Service / Provider name
  const providerName =
    legs[0]?.service?.name ||
    journey.metadata?.provider ||
    legs[0]?.service?.operator ||
    (transportModes[0] === 'road' ? 'Road Transit' : null);

  const isBestOverall = Boolean(isTopPick);
  const rankingLabel = isTopPick ? 'Best Overall' : (journey.ranking?.label !== 'Best Overall' ? journey.ranking?.label : null);

  const isUnreserved = Boolean(
    journey.isUnreserved ||
    journey.metadata?.isUnreserved ||
    journey.availabilityStatus === 'UNRESERVED' ||
    journey.metadata?.availabilityStatus === 'UNRESERVED' ||
    journey.availability?.normalizedStatus === 'UNRESERVED' ||
    journey.legs?.some((l) => l.booking?.status === 'unreserved' || l.availability?.normalizedStatus === 'UNRESERVED') ||
    /unreserved/i.test(journey.service?.class || '') ||
    /passenger|memu|demu|emu/i.test(journey.service?.name || '')
  );

  // Section 8: Explainable recommendation reasons
  const recommendationReasons = isBestOverall
    ? getRecommendationExplanation(journey, allJourneys)
    : [];

  const segmentSummaryLabel = isDirect
    ? 'Direct · 1 segment'
    : `${formatTransfers(transfers)} · ${legs.length} segments`;

  return (
    <article
      className={`rounded-2xl border bg-[#12151A] p-5 sm:p-6 transition-all shadow-xl ${
        isBestOverall
          ? 'border-[#E8B04A]/40 shadow-lg shadow-[#E8B04A]/5 ring-1 ring-[#E8B04A]/20'
          : 'border-[#303640] hover:border-[#3A414C] hover:bg-[#15191F]/30'
      }`}
      aria-label={`Journey from ${originName} to ${destinationName}, ${durationText}, ${priceLabel} ${priceText}`}
    >
      {/* 1. Header: Reorganized hierarchy with clear alignment */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#303640]/80 pb-3 sm:pb-3.5">
        <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 min-w-0">
          {/* Best Overall Badge */}
          {isBestOverall && (
            <span className="inline-flex items-center gap-1 rounded-full bg-[#E8B04A] px-2.5 py-0.5 text-[10px] font-bold text-[#0B0D10] shadow-sm shrink-0">
              <Sparkles className="h-3 w-3" aria-hidden="true" />
              <span>BEST OVERALL</span>
            </span>
          )}

          {/* Other Ranking Badge */}
          {!isBestOverall && rankingLabel && (
            <span className="inline-flex items-center gap-1 rounded-full bg-[#15191F] px-2.5 py-0.5 text-[11px] font-semibold text-[#A7AFBA] border border-[#303640] shrink-0">
              <span>{rankingLabel}</span>
            </span>
          )}

          {/* Transport Mode & Service / Operator */}
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F0F1F3] min-w-0">
            <PrimaryModeIcon className="h-3.5 w-3.5 text-[#E8B04A] shrink-0" aria-hidden="true" />
            <span className="capitalize">{transportModes.join(' + ')}</span>
            {providerName && (
              <span className="text-[#A7AFBA] truncate max-w-[220px] sm:max-w-[340px]" title={providerName}>
                · {providerName}
              </span>
            )}
          </div>

          {/* Direct (Green) or Transfer status Badge */}
          <span
            className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold shrink-0 ${
              isDirect
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'bg-[#15191F] text-[#A7AFBA] border border-[#303640]'
            }`}
          >
            {isDirect ? 'Direct' : formatTransfers(transfers)}
          </span>

          {/* Recovery Route Badge */}
          {journey.isRecoveredAlternative && (
            <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shrink-0">
              Recovered Route
            </span>
          )}

          {/* Station Shift Badge */}
          {(journey.isClusterShift || journey.stationDifference?.hasDifference || journey.metadata?.isClusterShift) && (
            <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20 shrink-0">
              Nearby Station
            </span>
          )}

          {/* Seat Availability Status Badge */}
          {isUnreserved ? (
            <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20 shrink-0">
              Unreserved
            </span>
          ) : (
            <>
              {((journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'AVAILABILITY_VERIFIED' ||
                ((journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'AVAILABLE' && journey.isBookable)) && (
                <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                  Seats Verified
                </span>
              )}
              {((journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'RAC_AVAILABLE' ||
                (journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'RAC' ||
                (journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'RAC_ONLY') && (
                <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
                  RAC
                </span>
              )}
              {((journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'WAITLIST_ONLY' ||
                (journey.availabilityStatus || journey.metadata?.availabilityStatus) === 'WAITLIST') && (
                <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
                  Waitlist
                </span>
              )}
              {journey.availabilityStatus === 'NOT_BOOKABLE' && (
                <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 shrink-0">
                  Not Bookable
                </span>
              )}
            </>
          )}
        </div>

        {/* Header Actions: Compare & Save */}
        <div className="flex items-center gap-1.5 text-xs shrink-0">
          {onToggleCompare && (
            <button
              type="button"
              onClick={() => onToggleCompare(journey)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs transition-colors cursor-pointer ${
                isCompared
                  ? 'bg-[#E8B04A] text-[#0B0D10] font-semibold'
                  : 'bg-[#15191F] text-[#A7AFBA] hover:text-[#F0F1F3] border border-[#303640] hover:border-[#3A414C]'
              }`}
              title="Add to comparison"
              aria-label={isCompared ? 'Remove from comparison' : 'Compare journey'}
            >
              <GitCompare className="h-3.5 w-3.5" />
              <span>{isCompared ? 'Compared' : 'Compare'}</span>
            </button>
          )}

          {isAuthenticated && (
            <button
              type="button"
              onClick={handleToggleSave}
              disabled={saving}
              className={`inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs transition-colors cursor-pointer ${
                saved
                  ? 'text-[#E8B04A] bg-[#E8B04A]/10'
                  : 'text-[#7E8794] hover:text-[#F0F1F3]'
              }`}
              title={saved ? 'Remove saved journey' : 'Save for later'}
              aria-label={saved ? 'Remove saved journey' : 'Save journey'}
            >
              <Bookmark className={`h-3.5 w-3.5 ${saved ? 'fill-[#E8B04A] text-[#E8B04A]' : ''}`} />
            </button>
          )}
        </div>
      </div>

      {/* 2. Recommendation Explanation */}
      {isBestOverall && recommendationReasons.length > 0 && (
        <div className="mt-3.5 rounded-xl border border-[#E8B04A]/20 bg-[#181C22] p-3 text-xs space-y-2">
          <div className="font-semibold text-[#E8B04A] flex items-center gap-1.5">
            <Sparkles className="h-3 w-3 shrink-0" />
            <span>Why Yatrai recommends this</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center gap-1.5 sm:gap-x-4 text-[#A7AFBA]">
            {recommendationReasons.map((reason, idx) => (
              <div key={idx} className="flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                <span>{reason}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Journey Summary & Fare Column */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-12 gap-5 items-center">
        {/* Departure, Duration Line, Arrival */}
        <div className="sm:col-span-8 flex items-start justify-between gap-3 sm:gap-4">
          {/* Departure */}
          <div className="flex-1 min-w-0">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#F0F1F3] font-mono tabular-nums">
              {depTime}
            </div>
            <div
              className="mt-1 text-sm font-semibold text-[#F0F1F3] leading-snug break-words"
              title={originName}
            >
              {originName}
            </div>
            {originCity && (
              <div className="text-xs text-[#7E8794] mt-0.5">{originCity}</div>
            )}
            {depDate && (
              <div className="text-xs text-[#7E8794] mt-0.5">{depDate}</div>
            )}
          </div>

          {/* Route path line & Duration */}
          <div className="flex flex-col items-center px-1 sm:px-2 flex-1 max-w-[140px] sm:max-w-[190px] shrink-0 pt-1">
            <div className="flex items-center gap-1 text-xs font-bold text-[#F0F1F3]">
              <Clock className="h-3 w-3 text-[#E8B04A] shrink-0" aria-hidden="true" />
              <span>{durationText}</span>
            </div>

            <div className="relative mt-2 w-full flex items-center justify-center">
              <div className="h-px w-full bg-[#303640]" />
              <div className="absolute flex h-2 w-2 rounded-full bg-[#E8B04A] ring-4 ring-[#12151A]" />
              <ArrowRight
                className="absolute right-0 h-3 w-3 text-[#7E8794] translate-x-0.5"
                aria-hidden="true"
              />
            </div>

            <div className="mt-1 text-[11px] text-[#7E8794] text-center">
              {isDirect ? 'Direct' : formatTransfers(transfers)}
              {journey.totalDistance ? ` · ${journey.totalDistance} km` : ''}
            </div>
          </div>

          {/* Arrival with Mandatory Day Offset */}
          <div className="flex-1 min-w-0 text-right">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#F0F1F3] font-mono tabular-nums flex items-baseline justify-end gap-1.5">
              <span>{arrTime}</span>
              {dayOffsetBadge && (
                <span className="rounded-md bg-[#E8B04A]/10 px-1.5 py-0.5 text-[11px] font-bold text-[#E8B04A] border border-[#E8B04A]/30">
                  {dayOffsetBadge}
                </span>
              )}
            </div>
            <div
              className="mt-1 text-sm font-semibold text-[#F0F1F3] leading-snug break-words"
              title={destinationName}
            >
              {destinationName}
            </div>
            {destinationCity && (
              <div className="text-xs text-[#7E8794] mt-0.5">{destinationCity}</div>
            )}
            {arrDate && (
              <div className="text-xs text-[#7E8794] mt-0.5">{arrDate}</div>
            )}
          </div>
        </div>

        {/* Fare & CTAs Column */}
        <div className="sm:col-span-4 flex flex-col sm:items-end justify-between pt-3 sm:pt-0 sm:border-l sm:border-[#303640] sm:pl-6 border-t border-[#303640] sm:border-t-0 gap-3">
          <div className="flex sm:flex-col justify-between sm:justify-start items-baseline sm:items-end w-full">
            <div className="text-[10px] uppercase tracking-wider text-[#7E8794] sm:text-right font-medium">
              {priceLabel}
            </div>
            <div className="text-2xl sm:text-3xl font-black tracking-tight text-[#F0F1F3] sm:text-right font-mono tabular-nums">
              {priceText}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap sm:flex-col items-stretch sm:items-end gap-2 w-full sm:w-auto">
            {onViewJourney && (
              <button
                type="button"
                onClick={() => onViewJourney(journey)}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#E8B04A] hover:bg-[#F2BE62] active:bg-[#D9A139] px-4 py-2.5 text-xs font-semibold text-[#0B0D10] shadow-md transition-all cursor-pointer focus:outline-none"
                aria-label={`View itinerary for ${originName} to ${destinationName}`}
              >
                <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                <span>View itinerary</span>
              </button>
            )}

            {legs.length > 0 && (
              <button
                type="button"
                onClick={() => setIsExpanded((prev) => !prev)}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1 rounded-xl border border-[#303640] bg-[#15191F] hover:bg-[#181C22] hover:border-[#3A414C] px-3 py-1.5 text-xs font-medium text-[#A7AFBA] hover:text-[#F0F1F3] transition-all cursor-pointer"
                aria-expanded={isExpanded}
                aria-label={isExpanded ? 'Collapse itinerary' : 'Expand itinerary'}
              >
                <span>{isExpanded ? 'Collapse' : (legs.length > 1 ? `${legs.length} segments` : 'Expand')}</span>
                {isExpanded ? (
                  <ChevronUp className="h-3 w-3" aria-hidden="true" />
                ) : (
                  <ChevronDown className="h-3 w-3" aria-hidden="true" />
                )}
              </button>
            )}

            {/* Railway Journey Details Action */}
            <button
              type="button"
              onClick={() => setBookingModalOpen(true)}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 rounded-xl border border-[#303640] bg-[#15191F] hover:bg-[#181C22] hover:border-[#3A414C] px-3.5 py-2 text-xs font-medium text-[#A7AFBA] hover:text-[#F0F1F3] transition-all cursor-pointer"
              aria-label="View railway booking guidelines and leg details"
            >
              <Ticket className="h-3.5 w-3.5 text-[#E8B04A]" aria-hidden="true" />
              <span>Journey details</span>
            </button>
          </div>
        </div>
      </div>

      {/* Station Cluster Shift Label */}
      {(journey.isClusterShift || journey.stationDifference?.hasDifference || journey.metadata?.isClusterShift) && (
        <div className="mt-3.5 flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-200">
          <AlertCircle className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" aria-hidden="true" />
          <div className="leading-relaxed">
            <span className="font-bold text-amber-300">Station cluster adjustment: </span>
            <span>
              {journey.stationDifference?.summaryLabel ||
                journey.clusterNote ||
                journey.metadata?.clusterNote ||
                'Departing or arriving at a nearby alternative station in the same metropolitan cluster.'}
            </span>
          </div>
        </div>
      )}

      {/* 4. Multi-Modal Collapsed Route Preview (when collapsed and >1 segment) */}
      {isMultiModal && !isExpanded && legs.length > 1 && (
        <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border border-graphite-800 bg-graphite-850/60 px-3 py-2 text-xs text-text-secondary">
          <span className="font-semibold text-text-tertiary">Route:</span>
          {legs.map((leg, idx) => {
            const LegIcon = getModeIcon(leg.mode);
            const oCode = leg.origin?.stationCode || leg.origin?.code || leg.metadata?.fromStationCode || '';
            const dCode = leg.destination?.stationCode || leg.destination?.code || leg.metadata?.toStationCode || '';
            const oName = leg.origin?.name || leg.metadata?.fromStationName || oCode || 'Origin';
            const dName = leg.destination?.name || leg.metadata?.toStationName || dCode || 'Destination';
            const lOrigin = oCode && !oName.includes(oCode) ? `${oName} (${oCode})` : oName;
            const lDest = dCode && !dName.includes(dCode) ? `${dName} (${dCode})` : dName;
            return (
              <span key={leg.id || idx} className="inline-flex items-center gap-1.5">
                {idx > 0 && <span className="text-text-tertiary">·</span>}
                <LegIcon className="h-3 w-3 text-brand-primary" aria-hidden="true" />
                <span className="truncate max-w-[150px]" title={`${lOrigin} → ${lDest}`}>
                  {lOrigin} → {lDest}
                </span>
              </span>
            );
          })}
        </div>
      )}

      {/* 5. Expanded Vertical Timeline Itinerary */}
      {isExpanded && legs.length > 0 && (
        <div className="mt-4 border-t border-graphite-800 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-text-primary">
                YOUR ITINERARY
              </h4>
              <p className="text-xs text-text-tertiary font-medium mt-0.5">
                {segmentSummaryLabel}
              </p>
            </div>
            {onViewJourney && (
              <button
                type="button"
                onClick={() => onViewJourney(journey)}
                className="text-xs font-semibold text-brand-primary hover:text-brand-hover hover:underline cursor-pointer transition-colors"
              >
                View route map →
              </button>
            )}
          </div>

          <div className="space-y-3 rounded-xl border border-graphite-800 bg-graphite-850/50 p-3 sm:p-4">
            {legs.map((leg, index) => (
              <JourneyLeg
                key={leg.id || index}
                leg={leg}
                isLast={index === legs.length - 1}
                nextLeg={legs[index + 1] || null}
              />
            ))}
          </div>
        </div>
      )}

      {/* Booking Preparation & IRCTC Compliance Modal */}
      {bookingModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in"
          onClick={() => setBookingModalOpen(false)}
        >
          <div
            className="relative w-full max-w-lg rounded-2xl border border-white/10 bg-surface-primary p-6 shadow-2xl space-y-4 text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Ticket className="h-5 w-5 text-brand-primary" />
                <h3 className="text-base font-bold text-text-primary">Railway Booking Guidelines</h3>
              </div>
              <button
                type="button"
                onClick={() => setBookingModalOpen(false)}
                className="rounded-lg p-1 text-text-tertiary hover:text-text-primary cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="text-xs text-text-secondary space-y-2">
              <p className="font-semibold text-text-primary">
                {isDirect
                  ? 'Direct Train Booking'
                  : 'Multi-Leg Alternative Journey (Legs Booked Separately)'}
              </p>
              <p>
                {isDirect
                  ? 'This journey is operated as a single direct train. You can book directly using the train number below on IRCTC or an authorized booking partner.'
                  : 'Per Indian Railways (IRCTC) booking regulations, connecting journeys cannot be issued under a single unified ticket. Each leg must be booked independently using its specific train number and boarding station. Yatrai has verified seat availability for each leg.'}
              </p>
            </div>

            {/* Leg breakdown list */}
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {legs.map((leg, i) => {
                const legFare = leg.price != null && leg.price > 0 ? leg.price : null;
                const legAvailStatus = leg.availability?.normalizedStatus || leg.availability?.status || 'UNKNOWN';
                const legRawStatus = leg.availability?.rawStatus || '';
                return (
                  <div key={i} className="rounded-xl border border-white/10 bg-surface-secondary/70 p-3 text-xs space-y-1">
                    <div className="flex items-center justify-between font-bold text-text-primary">
                      <span>Leg {i + 1}: {leg.service?.name || 'Train'} (#{leg.service?.number || leg.trainNumber})</span>
                      <span className={legFare ? 'text-emerald-400 font-mono' : 'text-[#7E8794] font-normal'}>
                        {legFare
                          ? (leg.isEstimated || leg.pricing?.isEstimated || leg.fareSource === 'estimate'
                              ? `Est. ₹${legFare} (distance-based)`
                              : `₹${legFare}`)
                          : 'Fare unavailable'}
                      </span>
                    </div>
                    <div className="text-text-secondary">
                      {leg.origin?.name || leg.origin?.city} → {leg.destination?.name || leg.destination?.city}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-text-tertiary">
                      <span>Class: {leg.service?.class || 'SL'}</span>
                      <span>· Status: {legRawStatus || legAvailStatus}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Total Fare & Compliance Warning */}
            <div className="flex items-center justify-between border-t border-white/10 pt-2 text-xs">
              <span className="text-text-secondary font-medium">{priceLabel}:</span>
              <span className="text-base font-bold font-mono text-text-primary">{priceText}</span>
            </div>

            <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-3 text-xs text-amber-300 flex items-start gap-2">
              <AlertCircle className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
              <span>
                Yatrai does not store sensitive payment details or auto-book without your explicit IRCTC account authorization.
              </span>
            </div>

            <div className="rounded-xl border border-[#303640] bg-[#15191F] p-3 text-[11px] text-[#7E8794] flex items-start gap-2">
              <AlertCircle className="h-3.5 w-3.5 shrink-0 text-[#7E8794] mt-0.5" />
              <span>
                Availability and fares shown are indicative and may have changed.
                Book on{' '}
                <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="text-[#E8B04A] hover:underline">
                  IRCTC
                </a>{' '}
                for confirmed status.
              </span>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setBookingModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-text-secondary hover:text-text-primary cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                id="modal-book-now-btn"
                onClick={handleBookNow}
                disabled={bookingLoading}
                className="inline-flex items-center gap-2 rounded-xl bg-brand-primary px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-brand-hover active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
              >
                {bookingLoading ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <span>Book Now</span>
                    <Ticket className="h-3.5 w-3.5" />
                  </>
                )}
              </button>
            </div>
            {bookingError && (
              <p className="text-xs text-red-400 text-right mt-1">{bookingError}</p>
            )}
          </div>
        </div>
      )}
    </article>
  );
}

export default JourneyResultCard;
