import mongoose from 'mongoose';
import logger from '../utils/logger.js';
import locationService from './locationService.js';
import searchRequestService from './searchRequestService.js';
import journeySearchEngine from '../search/journeySearchEngine.js';
import Location from '../models/Location.js';
import rankingEngine from '../ranking/rankingEngine.js';

/**
 * Resolves a location input into a canonical Location Mongoose document.
 * Accepts:
 * - Location Mongoose/JSON document with _id
 * - Valid 24-hex MongoDB ObjectId string
 * - Free-text place name / travel phrase resolved via Phase 3 Location Resolution
 *
 * @param {string|Object} input
 * @param {string} label - 'origin' or 'destination'
 * @returns {Promise<Object|null>} Canonical Location document
 */
export async function resolveLocation(input, label = 'location') {
  if (!input) return null;

  // Case 1: Object with _id
  if (typeof input === 'object' && input._id) {
    if (mongoose.Types.ObjectId.isValid(input._id)) {
      const doc = await Location.findById(input._id);
      if (doc) return doc;
    }
  }

  const clean = typeof input === 'string' ? input.trim() : '';

  // Case 2: 24-character hexadecimal ObjectId
  if (clean && /^[0-9a-fA-F]{24}$/.test(clean) && mongoose.Types.ObjectId.isValid(clean)) {
    const doc = await Location.findById(clean);
    if (doc) return doc;
  }

  // Case 3: Text query or object without valid ObjectId
  let target = input;
  if (clean) {
    logger.debug(`[JourneySearchService] Resolving ${label} text query: "${clean}"`);
    const resolved = await locationService.resolveSingle(clean);
    if (resolved) {
      target = resolved;
    } else {
      const candidates = await locationService.search(clean, { limit: 1 });
      if (candidates && candidates.length > 0) {
        target = candidates[0];
      }
    }
  }

  if (!target) return null;

  // Ensure target is backed by a real MongoDB Location document with a valid ObjectId
  const currentId = target._id || target.id;
  if (currentId && mongoose.Types.ObjectId.isValid(currentId)) {
    const doc = await Location.findById(currentId);
    if (doc) return doc;
  }

  const query = {};
  if (target.stationCode) query.stationCode = target.stationCode;
  else if (target.placeId) query.placeId = target.placeId;
  else if (target.name) query.name = target.name;

  if (Object.keys(query).length > 0) {
    const existing = await Location.findOne(query);
    if (existing) return existing;
  }

  try {
    const doc = new Location({
      name: target.name || 'Unknown Location',
      type: target.type || 'station',
      stationCode: target.stationCode || undefined,
      city: target.city || target.name,
      state: target.state || undefined,
      country: target.country || 'India',
      location: target.location || {
        type: 'Point',
        coordinates: [target.longitude || 0, target.latitude || 0],
      },
      placeId: target.placeId || (target.stationCode ? `station:${target.stationCode}` : undefined),
    });
    return await doc.save();
  } catch (err) {
    logger.warn(`Failed to persist location in resolveLocation: ${err.message}`);
    return target;
  }
}

import journeyOrchestrator from '../orchestration/journeyOrchestrator.js';

const originalEngineSearch = journeySearchEngine.search;

export const journeySearchService = {
  async searchJourneys(params) {
    // If a test specifically monkey-patches journeySearchEngine.search, preserve legacy pipeline
    if (journeySearchEngine.search !== originalEngineSearch) {
      const {
        origin: rawOrigin,
        destination: rawDestination,
        departureDate: rawDepDate,
        returnDate: rawRetDate,
        passengers = 1,
        requestedModes = [],
        preferences = {},
        ranking,
        sortBy,
        userId = null,
        candidateSources,
      } = params;

      if (!rawOrigin) {
        const err = new Error('Origin location is required.');
        err.statusCode = 400;
        err.code = 'VALIDATION_ERROR';
        throw err;
      }
      if (!rawDestination) {
        const err = new Error('Destination location is required.');
        err.statusCode = 400;
        err.code = 'VALIDATION_ERROR';
        throw err;
      }
      if (!rawDepDate) {
        const err = new Error('Departure date is required.');
        err.statusCode = 400;
        err.code = 'VALIDATION_ERROR';
        throw err;
      }

      const departureDate = rawDepDate instanceof Date ? rawDepDate : new Date(rawDepDate);
      if (isNaN(departureDate.getTime())) {
        const err = new Error('Invalid departure date provided.');
        err.statusCode = 400;
        err.code = 'VALIDATION_ERROR';
        throw err;
      }

      const [originLocation, destLocation] = await Promise.all([
        resolveLocation(rawOrigin, 'origin'),
        resolveLocation(rawDestination, 'destination'),
      ]);

      if (!originLocation) {
        const err = new Error(`Unable to resolve origin location "${typeof rawOrigin === 'string' ? rawOrigin : rawOrigin?.name || 'unknown'}".`);
        err.statusCode = 404;
        err.code = 'LOCATION_NOT_FOUND';
        throw err;
      }
      if (!destLocation) {
        const err = new Error(`Unable to resolve destination location "${typeof rawDestination === 'string' ? rawDestination : rawDestination?.name || 'unknown'}".`);
        err.statusCode = 404;
        err.code = 'LOCATION_NOT_FOUND';
        throw err;
      }

      let searchRequest = await searchRequestService.create({
        user: userId || null,
        origin: originLocation._id || originLocation,
        destination: destLocation._id || destLocation,
        departureDate,
        returnDate: rawRetDate ? new Date(rawRetDate) : null,
        passengers: Number(passengers) || 1,
        preferences: {
          priority: preferences.priority || 'balanced',
          maxBudget: preferences.maxBudget !== undefined ? Number(preferences.maxBudget) : null,
          maxTransfers: preferences.maxTransfers !== undefined ? Number(preferences.maxTransfers) : null,
        },
        requestedModes: Array.isArray(requestedModes) ? requestedModes : [],
        status: 'pending',
      });

      await searchRequestService.updateStatus(searchRequest._id, 'processing');

      try {
        const journeys = await journeySearchEngine.search({
          searchRequest,
          origin: originLocation,
          destination: destLocation,
          departureDate,
          passengers: Number(passengers) || 1,
          requestedModes: Array.isArray(requestedModes) ? requestedModes : [],
          preferences,
          candidateSources,
        });

        const rankingStrategy = ranking || sortBy || preferences.priority || 'overall';
        const rankedJourneys = rankingEngine.rank(journeys, rankingStrategy, {
          preferences,
          passengers: Number(passengers) || 1,
        });

        await searchRequestService.updateStatus(searchRequest._id, 'completed');
        const strategyInstance = rankingEngine.registry.get(rankingStrategy);

        return {
          searchRequest,
          origin: originLocation,
          destination: destLocation,
          ranking: {
            strategy: strategyInstance ? strategyInstance.id : rankingStrategy,
            label: strategyInstance ? strategyInstance.name : 'Best Overall',
          },
          journeys: rankedJourneys,
        };
      } catch (pipelineError) {
        logger.error('[JourneySearchService] Search pipeline failed:', pipelineError);
        if (searchRequest && searchRequest._id) {
          try {
            await searchRequestService.updateStatus(searchRequest._id, 'failed');
          } catch (failStatusErr) {
            logger.error(`[JourneySearchService] Failed to set SearchRequest status to failed: ${failStatusErr.message}`);
          }
        }
        throw pipelineError;
      }
    }

    // Default: Delegate completely to the Phase 8 Journey Orchestrator
    const result = await journeyOrchestrator.orchestrateSearch(params);
    return result;
  },
};

export default journeySearchService;
