import mongoose from 'mongoose';
import SavedJourney from '../models/SavedJourney.js';
import Journey from '../models/Journey.js';
import JourneyLeg from '../models/JourneyLeg.js';

/**
 * Format a populated Location document safely
 */
function formatLocation(loc) {
  if (!loc) return null;
  return {
    id: loc._id ? loc._id.toString() : loc.id || null,
    name: loc.name || '',
    displayName: loc.displayName || loc.name || '',
    city: loc.city || '',
    state: loc.state || '',
    type: loc.type || 'station',
    coordinates: loc.location?.coordinates || loc.coordinates || null,
  };
}

/**
 * Formats a canonical Journey and its legs into the standard response shape
 */
function formatJourneyPayload(journeyDoc, legs = []) {
  if (!journeyDoc) return null;
  const raw = typeof journeyDoc.toJSON === 'function' ? journeyDoc.toJSON() : journeyDoc;

  return {
    id: raw._id ? raw._id.toString() : raw.id,
    origin: formatLocation(raw.origin),
    destination: formatLocation(raw.destination),
    departureTime: raw.departureTime ? new Date(raw.departureTime).toISOString() : null,
    arrivalTime: raw.arrivalTime ? new Date(raw.arrivalTime).toISOString() : null,
    duration: raw.duration,
    totalDistance: raw.totalDistance || 0,
    totalPrice: raw.totalPrice,
    currency: raw.currency || 'INR',
    numberOfTransfers: raw.numberOfTransfers || 0,
    transportModes: raw.transportModes || [],
    status: raw.status || 'scheduled',
    legs: legs.map((leg) => {
      const legRaw = typeof leg.toJSON === 'function' ? leg.toJSON() : leg;
      return {
        id: legRaw._id ? legRaw._id.toString() : legRaw.id,
        sequence: legRaw.sequence,
        origin: formatLocation(legRaw.origin),
        destination: formatLocation(legRaw.destination),
        mode: legRaw.mode,
        provider: legRaw.provider
          ? {
              id: legRaw.provider._id?.toString() || legRaw.provider.id,
              name: legRaw.provider.name,
              code: legRaw.provider.code,
            }
          : null,
        departureTime: legRaw.departureTime ? new Date(legRaw.departureTime).toISOString() : null,
        arrivalTime: legRaw.arrivalTime ? new Date(legRaw.arrivalTime).toISOString() : null,
        duration: legRaw.duration,
        distance: legRaw.distance || 0,
        price: legRaw.price || 0,
        currency: legRaw.currency || 'INR',
        vehicle: legRaw.vehicle || {},
        service: {
          ...(legRaw.service || {}),
          number: legRaw.service?.number || legRaw.vehicle?.identifier || '',
        },
        booking: legRaw.booking || {},
      };
    }),
    metadata: raw.metadata || {},
    createdAt: raw.createdAt,
  };
}

/**
 * Saved Journey Service (Phase 13)
 * Scoped strictly to authenticated users with complete IDOR protection.
 */
export const savedJourneyService = {
  /**
   * Save a canonical journey for an authenticated user.
   *
   * @param {Object} params
   * @param {string|mongoose.Types.ObjectId} params.userId
   * @param {string|mongoose.Types.ObjectId} params.journeyId
   * @param {string} [params.name]
   * @param {string} [params.notes]
   * @returns {Promise<Object>}
   */
  async saveJourney(firstArg, secondArg, thirdArg, fourthArg) {
    const isObjectInvocation =
      typeof firstArg === 'object' &&
      !mongoose.Types.ObjectId.isValid(firstArg) &&
      firstArg !== null &&
      firstArg?.userId;

    const userId = isObjectInvocation ? firstArg.userId : firstArg;
    const journeyId = isObjectInvocation ? firstArg.journeyId : secondArg;
    const name = (isObjectInvocation ? firstArg.name : thirdArg) || '';
    const notes = (isObjectInvocation ? firstArg.notes : fourthArg) || '';

    if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
      const err = new Error('Invalid user identifier.');
      err.statusCode = 400;
      err.code = 'INVALID_USER_ID';
      throw err;
    }
    if (!journeyId || !mongoose.Types.ObjectId.isValid(journeyId)) {
      const err = new Error('Invalid journey identifier.');
      err.statusCode = 400;
      err.code = 'INVALID_JOURNEY_ID';
      throw err;
    }

    // Ensure journey actually exists
    const journeyExists = await Journey.exists({ _id: journeyId });
    if (!journeyExists) {
      const err = new Error('Journey not found.');
      err.statusCode = 404;
      err.code = 'JOURNEY_NOT_FOUND';
      throw err;
    }

    // Check if already saved for object-based API invocations
    if (isObjectInvocation) {
      const existing = await SavedJourney.findOne({ user: userId, journey: journeyId });
      if (existing) {
        return {
          _id: existing._id,
          saved: true,
          alreadySaved: true,
          savedJourneyId: existing._id.toString(),
          message: 'Journey is already saved.',
        };
      }
    }

    const savedDoc = await SavedJourney.create({
      user: userId,
      journey: journeyId,
      name: name?.trim() || '',
      notes: notes?.trim() || '',
    });

    if (isObjectInvocation) {
      return {
        _id: savedDoc._id,
        saved: true,
        alreadySaved: false,
        savedJourneyId: savedDoc._id.toString(),
        message: 'Journey saved successfully.',
      };
    }

    return savedDoc;
  },

  /**
   * Remove a saved journey for an authenticated user.
   *
   * @param {Object} params
   * @param {string|mongoose.Types.ObjectId} params.userId
   * @param {string|mongoose.Types.ObjectId} params.journeyId - Either SavedJourney _id or Journey _id
   * @returns {Promise<Object>}
   */
  async removeSavedJourney({ userId, journeyId }) {
    if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
      const err = new Error('Invalid user identifier.');
      err.statusCode = 400;
      err.code = 'INVALID_USER_ID';
      throw err;
    }
    if (!journeyId || !mongoose.Types.ObjectId.isValid(journeyId)) {
      const err = new Error('Invalid identifier.');
      err.statusCode = 400;
      err.code = 'INVALID_IDENTIFIER';
      throw err;
    }

    // Delete matching user and either journey reference or saved journey document id
    const result = await SavedJourney.findOneAndDelete({
      user: userId,
      $or: [{ _id: journeyId }, { journey: journeyId }],
    });

    if (!result) {
      const err = new Error('Saved journey record not found or not owned by user.');
      err.statusCode = 404;
      err.code = 'SAVED_JOURNEY_NOT_FOUND';
      throw err;
    }

    return {
      saved: false,
      message: 'Saved journey removed successfully.',
    };
  },

  /**
   * List all saved journeys for an authenticated user.
   *
   * @param {string|mongoose.Types.ObjectId} userId
   * @returns {Promise<Array<Object>>}
   */
  async listSavedJourneys(userId) {
    if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
      const err = new Error('Invalid user identifier.');
      err.statusCode = 400;
      err.code = 'INVALID_USER_ID';
      throw err;
    }

    const savedRecords = await SavedJourney.find({ user: userId })
      .sort({ createdAt: -1 })
      .populate({
        path: 'journey',
        populate: [
          { path: 'origin' },
          { path: 'destination' },
        ],
      });

    // Populate legs for each journey
    const results = [];
    for (const record of savedRecords) {
      if (!record.journey) continue;

      const legs = await JourneyLeg.find({ journey: record.journey._id })
        .sort({ sequence: 1 })
        .populate('origin')
        .populate('destination')
        .populate('provider');

      const formattedJourney = formatJourneyPayload(record.journey, legs);
      if (formattedJourney) {
        results.push({
          savedJourneyId: record._id.toString(),
          savedAt: record.createdAt,
          name: record.name,
          notes: record.notes,
          journey: formattedJourney,
        });
      }
    }

    return results;
  },

  /**
   * Check if a specific journey is saved by the user.
   *
   * @param {Object} params
   * @param {string|mongoose.Types.ObjectId} params.userId
   * @param {string|mongoose.Types.ObjectId} params.journeyId
   * @returns {Promise<{ isSaved: boolean }>}
   */
  async checkIsSaved({ userId, journeyId }) {
    if (!userId || !journeyId || !mongoose.Types.ObjectId.isValid(journeyId)) {
      return { isSaved: false };
    }
    const exists = await SavedJourney.exists({ user: userId, journey: journeyId });
    return { isSaved: Boolean(exists) };
  },
};

export default savedJourneyService;
